// // routes/authRoutes.js
// const express = require('express');
// const router = express.Router();
// const User = require('../models/user');
// const bcrypt = require('bcrypt');
// const jwt = require('jsonwebtoken');

// // Login route
// router.post('/login', async (req, res) => {
//   const { email, password } = req.body;

//   try {
//     // Find user by email
//     const user = await User.findOne({ email });
//     if (!user) return res.status(400).json({ message: 'Invalid credentials' });

//     // Compare password with hashed password
//     const match = await bcrypt.compare(password, user.password);
//     if (!match) return res.status(400).json({ message: 'Invalid credentials' });

//     // Generate JWT token
//     const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '24h' });

//     res.json({ token });
//   } catch (error) {
//     console.error('Error in login route:', error.message);
//     res.status(500).json({ message: error.message });
//   }


// });


 

// module.exports = router;

