// seedproducts.js
const mongoose = require('mongoose');
const Product = require('./models/product');

mongoose.connect('mongodb://localhost:27017/ecommerce', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const localproducts = [
  { name: 'Product 1', image: '/public/product1.jpg', price: 19.99 },
  { name: 'Product 2', image: '/public/product2.jpg', price: 29.99 },
  { name: 'Product 3', image: '/public/product3.jpg', price: 39.99 },
  { name: 'Product 4', image: '/public/product4.jpg', price: 49.99 },
];

const seedDB = async () => {
  await Product.deleteMany({});
  await Product.insertMany(localproducts);
  console.log('Database seeded!');
  mongoose.connection.close();
};

seedDB();
